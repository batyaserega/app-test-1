//
//  ViewController.swift
//  APP-test
//
//  Created by batya on 04.09.2023.
//
import UIKit
var urlapi:String = "http://127.0.0.1:8000"
var urlapipostfix:String = "/api/v1/womenlist"
var urlpostfixuserinfo:String = "/api/v1/userinfo"


class ViewController: UIViewController {
    var phonenumber:String = "12345"
    var passworduser:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var TextPhone1: UITextField!
    @IBOutlet weak var Labeltest: UILabel!
    @IBOutlet weak var TextPassword: UITextField!
    @IBOutlet weak var LabelPass: UILabel!
    @IBOutlet weak var textPass: UITextField!
    @IBOutlet weak var TextMail: UITextField!
    @IBOutlet weak var TextUserName: UITextField!
    

    
    @IBAction func buttonr(_ sender: UIButton) {
        phonenumber = TextPhone1.text ?? "11"
        passworduser = textPass.text ?? "22"
        Labeltest.text = phonenumber
        let getdate = GetDateTime()
        LabelPass.text = getdate
      
       
        guard let url = URL(string: urlapi + urlapipostfix) else {return}
        
        let parameters = [ "phone_number": phonenumber]
        let session = URLSession.shared
        session.dataTask(with: url) { (data,response,error) in
            if let response = response {print(response)
        }
            guard let data = data else {return}
            print(data)
            do
            {
                let json = try JSONSerialization.jsonObject(with: data, options:[])
                print(json)
        } catch
            {
            print(error)
        }
        }.resume()
    }
    

    
    @IBAction func buttonregtest(_ sender: UIButton) {
        guard let url = URL(string: urlapi + urlapipostfix) else {return}
        var getdate = GetDateTime()
        var _Phonenumber:String = TextPhone1.text ?? "11"
        var _Email:String = TextMail.text ?? "1"
        var _Nameuser:String = TextUserName.text ?? "1"
        let _currentDateTime = getdate 
        //Labeltest = getdate;
         
        let parameters = [ "phone_number": _Phonenumber,
                           "email": _Email,
                           "nameuser": _Nameuser,
                           "datetimecreate": _currentDateTime]
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else {return}
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            guard let data = data else {return}
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                print(json)
            } catch {
                print(error)
            }
        }.resume()
    }
    
    @IBAction func TextPhone(_ sender: UITextView) {
    }
    
    @IBAction func RegButtonPressed(_ sender: UIButton ) {
        
    }
    @IBAction func buttongetinfouser(_ sender: UIButton) {
        
            guard let url = URL(string: urlapi + urlpostfixuserinfo) else {return}
        
            var _Phonenumber:String = TextPhone1.text ?? "11"
        
            let parameters = [ "phone_number": _Phonenumber]
        
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else {return}
            request.httpBody = httpBody
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                if let response = response {
                    print(response)
                }
                guard let data = data else {return}
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print(error)
                }
            }.resume()
    }
}

